# Simple RAG System

This is a simple, lightweight Retrieval-Augmented Generation (RAG) implementation in Python.

## Core Features
1. **Document Chunking**: Sliding-window based text segmenter.
2. **Local Embeddings**: Generating embeddings offline using `sentence-transformers`.
3. **Vector Database**: Clean in-memory database using `numpy` with cosine similarity search and storage backup.
4. **Context-Augmented Generation**: Integrates with Gemini API via the `google-generativeai` package (falls back to printing context-augmented prompt if no key is set).

## Setup

1. **Install Dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

2. **Set up Gemini API Key (Optional)**:
   To run LLM generation, set your API key in the environment:
   - Windows (PowerShell):
     ```powershell
     $env:GEMINI_API_KEY="your-api-key"
     ```
   - Linux/macOS:
     ```bash
     export GEMINI_API_KEY="your-api-key"
     ```

## Usage

### 1. Ingest Documents
Ingest all text files in a directory (like the sample `./data/` directory):
```bash
python main.py ingest ./data
```

### 2. Query
Query the system:
```bash
python main.py query "Who is the CEO of Acme Corp?"
```
Or query offline to see the constructed prompt:
```bash
python main.py query "Does AgentForge run offline?"
```
